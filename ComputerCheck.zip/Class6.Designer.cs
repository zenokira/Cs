﻿namespace ComputerCheck
{
    partial class Class6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            label7 = new Label();
            label9 = new Label();
            label8 = new Label();
            label6 = new Label();
            SuspendLayout();
            // 
            // textBox5
            // 
            textBox5.Location = new Point(478, 356);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(250, 23);
            textBox5.TabIndex = 23;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(478, 292);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(250, 23);
            textBox4.TabIndex = 22;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(478, 212);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(250, 23);
            textBox3.TabIndex = 21;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(478, 131);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(250, 23);
            textBox2.TabIndex = 20;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(478, 56);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(250, 23);
            textBox1.TabIndex = 19;
            // 
            // label1
            // 
            label1.BackColor = Color.Green;
            label1.Font = new Font("맑은 고딕", 15F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(410, 37);
            label1.Name = "label1";
            label1.Size = new Size(50, 50);
            label1.TabIndex = 16;
            label1.Text = "1";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.BackColor = Color.Green;
            label2.Font = new Font("맑은 고딕", 15F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(410, 112);
            label2.Name = "label2";
            label2.Size = new Size(50, 50);
            label2.TabIndex = 15;
            label2.Text = "2";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Green;
            label3.Font = new Font("맑은 고딕", 15F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(410, 193);
            label3.Name = "label3";
            label3.Size = new Size(50, 50);
            label3.TabIndex = 12;
            label3.Text = "3";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.BackColor = Color.Green;
            label4.Font = new Font("맑은 고딕", 15F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(410, 273);
            label4.Name = "label4";
            label4.Size = new Size(50, 50);
            label4.TabIndex = 11;
            label4.Text = "4";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.BackColor = Color.Green;
            label5.Font = new Font("맑은 고딕", 15F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(410, 347);
            label5.Name = "label5";
            label5.Size = new Size(50, 50);
            label5.TabIndex = 10;
            label5.Text = "5";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(114, 282);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(250, 23);
            textBox9.TabIndex = 35;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(114, 212);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(250, 23);
            textBox8.TabIndex = 34;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(114, 131);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(250, 23);
            textBox7.TabIndex = 33;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(114, 56);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(250, 23);
            textBox6.TabIndex = 32;
            // 
            // label7
            // 
            label7.BackColor = Color.Green;
            label7.Font = new Font("맑은 고딕", 15F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(31, 112);
            label7.Name = "label7";
            label7.Size = new Size(50, 50);
            label7.TabIndex = 30;
            label7.Text = "7";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            label9.BackColor = Color.Green;
            label9.Font = new Font("맑은 고딕", 15F);
            label9.ForeColor = Color.White;
            label9.Location = new Point(31, 273);
            label9.Name = "label9";
            label9.Size = new Size(50, 50);
            label9.TabIndex = 29;
            label9.Text = "9";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            label8.BackColor = Color.Green;
            label8.Font = new Font("맑은 고딕", 15F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(31, 193);
            label8.Name = "label8";
            label8.Size = new Size(50, 50);
            label8.TabIndex = 28;
            label8.Text = "8";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.BackColor = Color.Green;
            label6.Font = new Font("맑은 고딕", 15F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(31, 37);
            label6.Name = "label6";
            label6.Size = new Size(50, 50);
            label6.TabIndex = 31;
            label6.Text = "6";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Class6
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(label7);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label5);
            Name = "Class6";
            Text = "6강의실";
            Load += Class6_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private Label label7;
        private Label label9;
        private Label label8;
        private Label label6;
    }
}