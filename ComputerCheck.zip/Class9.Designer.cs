﻿namespace ComputerCheck
{
    partial class Class9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // textBox6
            // 
            textBox6.Location = new Point(467, 67);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(250, 23);
            textBox6.TabIndex = 24;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(467, 147);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(250, 23);
            textBox5.TabIndex = 23;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(467, 226);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(250, 23);
            textBox4.TabIndex = 22;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(116, 67);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(250, 23);
            textBox3.TabIndex = 21;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(116, 147);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(250, 23);
            textBox2.TabIndex = 20;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(116, 226);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(250, 23);
            textBox1.TabIndex = 19;
            // 
            // label1
            // 
            label1.BackColor = Color.Green;
            label1.Font = new Font("맑은 고딕", 15F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(48, 207);
            label1.Name = "label1";
            label1.Size = new Size(50, 50);
            label1.TabIndex = 16;
            label1.Text = "1";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.BackColor = Color.Green;
            label2.Font = new Font("맑은 고딕", 15F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(48, 128);
            label2.Name = "label2";
            label2.Size = new Size(50, 50);
            label2.TabIndex = 15;
            label2.Text = "2";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Green;
            label3.Font = new Font("맑은 고딕", 15F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(48, 48);
            label3.Name = "label3";
            label3.Size = new Size(50, 50);
            label3.TabIndex = 12;
            label3.Text = "3";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.BackColor = Color.Green;
            label4.Font = new Font("맑은 고딕", 15F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(397, 207);
            label4.Name = "label4";
            label4.Size = new Size(50, 50);
            label4.TabIndex = 11;
            label4.Text = "4";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.BackColor = Color.Green;
            label6.Font = new Font("맑은 고딕", 15F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(397, 48);
            label6.Name = "label6";
            label6.Size = new Size(50, 50);
            label6.TabIndex = 18;
            label6.Text = "6";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.BackColor = Color.Green;
            label5.Font = new Font("맑은 고딕", 15F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(399, 130);
            label5.Name = "label5";
            label5.Size = new Size(50, 50);
            label5.TabIndex = 10;
            label5.Text = "5";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Class9
            // 
            ClientSize = new Size(800, 450);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label6);
            Controls.Add(label5);
            Name = "Class9";
            Text = "9강의실";
            Load += Class9_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label5;
    }
}