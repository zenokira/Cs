﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ComputerCheck
{
    public partial class ClassPro : Form
    {
        const int LEFT_X = 50;
        const int RIGHT_X = 350;
        const int TOP = 25;
        const int BOTTOM = 325;
        const int COMPUTER_COUNT = 9;
        string FILENAME = "";
        string LoadJsonString;
        Computer[] computers = new Computer[COMPUTER_COUNT]; 
         
        public ClassPro(int numbering)
        {
            InitializeComponent();
            FILENAME = $"{numbering}강의실.json";
            for (int i = 0; i < COMPUTER_COUNT; i++)
            {
                if(i <= COMPUTER_COUNT / 2)
                    computers[i] = new Computer(new Point(LEFT_X, BOTTOM - 75*i),i+1 , Controls);
                else
                    computers[i] = new Computer(new Point(RIGHT_X, BOTTOM - 75 * (i - COMPUTER_COUNT / 2)), i+1, Controls);
            }
        }

        private void Class2_Load(object sender, EventArgs e)
        {
            LoadJson();
        }
        string getTodayNow()
        {
            return DateTime.Now.ToString();
        }
        public void SaveJson()
        {
            using (Stream ws = new FileStream(FILENAME, FileMode.OpenOrCreate))
            {
                string jsonString = $"[{getTodayNow()}]\n";

                for (int i = 0; i < COMPUTER_COUNT; i++)
                {
                    jsonString += $"[컴퓨터{i + 1}]\n";
                    jsonString += $"check : {computers[i].GetCheckState()}\n";
                    jsonString += $"comment : {computers[i].GetUpdateComment()}\n";
                }

                jsonString += $"\n\n{LoadJsonString}";
                byte[] jsonBytes = System.Text.Encoding.UTF8.GetBytes(jsonString);
                ws.Write(jsonBytes, 0, jsonBytes.Length);
                ws.Close();
            }
        }
        void LoadJson()
        {
            try
            {
                using (Stream rs = new FileStream(FILENAME, FileMode.Open))
                {
                    if (rs.Length == 0)
                    {
                        rs.Close();
                        return;
                    }
                    byte[] jsonBytes = new byte[rs.Length];
                    rs.Read(jsonBytes, 0, jsonBytes.Length);
                    LoadJsonString = System.Text.Encoding.UTF8.GetString(jsonBytes);

                    string[] str = LoadJsonString.Split('\n');

                    int idx = 0;
                    string preComment = "";
                    foreach (string s in str)
                    {
                        if (isStartWord(s)) continue;

                        if (isChecked(s)) preComment = sliceCheckComment(s) + " ";
                        if (isComment(s))
                        {
                            preComment += sliceMainComment(s);
                            computers[idx].SetPreComment(preComment);
                            idx++;
                            if (idx == COMPUTER_COUNT) break;
                        }
                    }
                    rs.Close();
                }
            }
            catch (FileNotFoundException e)
            {
                using (Stream ws = new FileStream("Error.txt", FileMode.Create))
                {
                    string jsonString = $"[{getTodayNow()}] {e}\n";
                    byte[] jsonBytes = System.Text.Encoding.UTF8.GetBytes(jsonString);
                    ws.Write(jsonBytes, 0, jsonBytes.Length);
                    ws.Close();
                }
            }
        }

        bool isStartWord(string str)
        {
            return str.StartsWith("[");
        }
        bool isChecked(string str)
        {
            return str.StartsWith("check");
        }

        bool isComment(string str)
        {
            return str.StartsWith("comment");
        }

        string sliceCheckComment(string str)
        {
            if (str.Contains("true")) 
                return "윈도우 점검o ";
            else 
                return "윈도우 점검x ";
        }

        string sliceMainComment(string str)
        {
            string s = str.Trim();
            if (s.Equals("")) return "";
            s = s.Substring(s.IndexOf(":") + 1);
            return s;
        }
    }
}