﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerCheck
{
    internal class Computer
    {
        const int LBL_TO_TBOX_X_GAP = 60;
        const int PRE_TO_UPDATE_Y_GAP = 27;
        const int TEXTBOX_X_SIZE = 180;
        const int TEXTBOX_Y_SIZE = 25;
        const int CHECK_X = LBL_TO_TBOX_X_GAP + TEXTBOX_X_SIZE + 10;

        Label Numbering = new Label();
        TextBox preComment = new TextBox();
        TextBox updateComment = new TextBox();
        CheckBox chckWindow = new CheckBox();

        Control.ControlCollection form_control;

        public Computer (Point point, int num, Control.ControlCollection control)
        {
            preComment.Location = point;
            form_control = control;
            Initialize(point,num);
        }

        void Initialize(Point point, int num )
        {
            InitLabel(point, num);
            InitTextBox(point,num);
            InitCheckBox(point,num);
        }

        void InitCheckBox(Point point, int num)
        {
            chckWindow.AutoSize = true;
            chckWindow.Name = $"checkBox{num}";
            chckWindow.Size = new Size(90, 19);
            chckWindow.TabIndex = num;
            chckWindow.Text = "점검";
            chckWindow.Location = new Point(point.X + CHECK_X, point.Y);
            chckWindow.UseVisualStyleBackColor = true;
            form_control.Add(chckWindow);
        }

        void InitTextBox(Point point, int num)
        {
            preComment.Location = new Point(point.X + LBL_TO_TBOX_X_GAP, point.Y);
            preComment.Multiline = true;  
            preComment.Size = new Size(TEXTBOX_X_SIZE, TEXTBOX_Y_SIZE);
            preComment.Name = $"preTextBox{num}";
            preComment.TabIndex = num;
            preComment.ReadOnly = true;
            form_control.Add(preComment);

            updateComment.Location = new Point(point.X + LBL_TO_TBOX_X_GAP, point.Y + PRE_TO_UPDATE_Y_GAP);
            updateComment.Multiline = true;
            updateComment.Size = new Size(TEXTBOX_X_SIZE, TEXTBOX_Y_SIZE);
            updateComment.Name = $"updateTextBox{num}";
            updateComment.TabIndex = num;
            form_control.Add(updateComment);
        }
        void InitLabel(Point point, int num)
        {
            Numbering.BackColor = Color.Green;
            Numbering.Font = new Font("맑은 고딕", 15F);
            Numbering.ForeColor = Color.White;
            Numbering.Location = point;
            Numbering.Size = new Size(50, 50);
            Numbering.TabIndex = 0;
            Numbering.Name = $"Label{num}";
            Numbering.Text = num.ToString();
            Numbering.TextAlign = ContentAlignment.MiddleCenter;
            form_control.Add(Numbering);
        }

        public void SetPreComment(String str)
        {
            preComment.Text = str;
        }

        public String GetUpdateComment()
        {
            return updateComment.Text;
        }

        public string GetCheckState()
        {
            if (chckWindow.Checked) return "true";
            else return "false";
        }
    }
}
